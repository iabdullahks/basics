myData = [
[31.45144485,74.294084572265, 'University of Management and Technology'],
[31.470326,74.4097439313104, 'Lahore University of Management Sciences'],
[31.4472954,74.26807703756918, 'University of Central Punjab'],
[31.3817679,74.2697977, 'Khayaban e Amin'],
[31.38988483761464,74.16868016391368, 'Bahria Town'],
[31.484237450000002,74.39499195261286, 'Devsinc'],
[32.68304,-99.13192, 'Ibex']
];
